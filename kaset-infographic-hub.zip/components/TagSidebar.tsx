// This file is no longer needed and can be deleted.
// The tag filtering functionality has been moved to SharedInfographicLayout.tsx
// as a horizontal filter bar.
